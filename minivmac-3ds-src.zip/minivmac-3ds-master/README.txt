MnvM_b35: README
Paul C. Pratt
www.gryphel.com
July 27, 2005


MnvM_b35 is the build system for Mini vMac,
a miniature Macintosh emulator.

Further information may be found at
"http://www.gryphel.com/c/minivmac/".


You can redistribute MnvM_b35 and/or modify it under the terms
of version 2 of the GNU General Public License as published by
the Free Software Foundation.  See the included file COPYING.

MnvM_b35 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
license for more details.
